class Application extends PIXI.Application {
  constructor(options = {}) {
    super(options);
    this.movers = [];
  }

  setup() {
    for (let i = 0; i < 20; i++) {
      let m = new Mover(
        Math.random() * this.stage.width,
        Math.random() * this.stage.height
      );
      m.target = new Vec2(400, 400);
      this.movers.push(m);
      this.stage.addChild(m);
    }
    this.ticker.add(this.update.bind(this));
  }

  update() {
    // #1 - Calculate "delta time"
    let dt = 1 / this.ticker.FPS;
    if (dt > 1 / 12) dt = 1 / 12;

    // #2 - Get Mouse Position
    let mousePosition = this.renderer.events.pointer.global;
    let mouseVector = new Vec2(mousePosition.x, mousePosition.y);

    // #3 - Move and draw the movers
    for (let m of this.movers) {
      m.target = mouseVector;
      m.update(dt);
      m.draw();
    }
  }
}
